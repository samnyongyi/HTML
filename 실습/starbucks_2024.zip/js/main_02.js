const searchEl = document.querySelector('.search');
const searchInputEl = searchEl.querySelector('input');

searchEl.addEventListener('click', function(){
    searchInputEl.focus();
});

searchInputEl.addEventListener('focus', function(){
    searchEl.classList.add('focused');
    searchInputEl.setAttribute('placeholder','통합검색');
});

searchInputEl.addEventListener('blur', function(){
    searchEl.classList.remove('focused');
    searchInputEl.setAttribute('placeholder','');
});

// Badges
const badgeEl = document.querySelector('header .badges');

window.addEventListener('scroll', function(){
    console.log('scroll!!');
});

window.addEventListener('scroll', _.throttle(
    function(){
        console.log('scroll!!');
        if(window.scrollY > 500){
            //배지 숨기기
            badgeEl.style.display = 'none';
        }
        else{
            badgeEl.style.display = 'block';
        }
    }, 300));

window.addEventListener('scroll', _.throttle(
    function(){
        console.log('scroll!!');
        if(window.scrollY > 500){
            //배지 숨기기
            gsap.to(badgeEl, 0.6, {
            opacity: 0,
            display: 'none'
            });
        }
        else{
            gsap.to(badgeEl, 0.6, {
                opacity: 1,
                display: 'block'
            });
        }
    }, 300));
        
    