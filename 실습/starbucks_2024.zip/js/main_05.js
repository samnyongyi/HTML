const searchEl = document.querySelector('.search');
const searchInputEl = searchEl.querySelector('input');

searchEl.addEventListener('click', function(){
    searchInputEl.focus();
});

searchInputEl.addEventListener('focus', function(){
    searchEl.classList.add('focused');
    searchInputEl.setAttribute('placeholder','통합검색');
});

searchInputEl.addEventListener('blur', function(){
    searchEl.classList.remove('focused');
    searchInputEl.setAttribute('placeholder','');
});

// Badges
const badgeEl = document.querySelector('header .badges');

window.addEventListener('scroll', _.throttle(
    function(){
      console.log('scroll!!');
      if(window.scrollY > 500){
        //배지 숨기기
        badgeEl.style.display = 'none';
        //구글링: gsap cdn
        //gsap.to(요소, 지속시간(s), 옵션);
        //주의: 시작적으로만 사라진다. --> display 옵션 추가
        gsap.to(badgeEl, 0.6, {
          opacity: 0,
          display: 'none'
        });
  
        //to-top button  보이기
        gsap.to('#to-top', 0.2, {
          x: 0
        });
      }
      else{
        badgeEl.style.display = 'block';
        gsap.to(badgeEl, 0.6, {
          opacity: 1,
          display: 'block'
        });
  
        //to-top button  숨기기: 오른쪽으로 이동
        gsap.to('#to-top', 0.2, {
          x: 100
        });
        
  
      }
    }, 300));
  
  const fadeEls=document.querySelectorAll('.visual .fade-in');
  fadeEls.forEach(function(fadeEl, index){
    gsap.to(fadeEl, 1,{
      delay: (index+1)*0.7,  //0.7 1.4 2.1 2.7 sec
      opacity:1
    });  
  });


  //notice ->swiper
  new Swiper('.notice--line .swiper',{
     direction: 'vertical',
     autoplay: true,
     loop: true
  });

  new Swiper('.promotion .swiper',{ 
     slidesPerView: 3, 
     spaceBetween: 10, 
     centeredSlides: true, 
     autoplay: {
        delay: 5000
     },
     loop: true,
     pagination:{
        el: '.promotion .swiper-pagination',
        clickable: true
     },
    navigation:{
      prevEl:'.promotion .swiper-prev',
      nextEl:'.promotion .swiper-next'
     }
    });

    const promotionEl = document.querySelector('.promotion');
    const promotionToggleBtn = document.querySelector('.toggle--promotion');
    const promotionToggleBtnImg = document.querySelector('.toggle--promotion .material-symbols-outlined');
    let isHidePromotion = false;
    promotionToggleBtn.addEventListener('click', function(){
      isHidePromotion = !isHidePromotion;
      if(isHidePromotion){
        //숨김 처리: hide 클래스 추가
        promotionEl.classList.add('hide'); 
        promotionToggleBtnImg.innerHTML= 'download';
      }
      else{
        //보임 처리: hide 클래스 삭제
        promotionEl.classList.remove('hide'); 
        promotionToggleBtnImg.innerHTML= 'upload';
      }
    });
    

/* Youtube */
var tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
var player;
function onYouTubeIframeAPIReady() {
  new YT.Player('player', { 
  videoId: 'An6LvWQuj_8',
   playerVars: {
   autoplay: true,
   loop: true,
   playlist: 'An6LvWQuj_8'
   },
   events:{
   onReady: function(event){
   event.target.mute();
   }
   }
  });
  }
  
    
        
    