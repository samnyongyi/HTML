const searchEl = document.querySelector('.search');
const searchInputEl = searchEl.querySelector('input');

searchEl.addEventListener('click', function(){
    searchInputEl.focus();
});

searchInputEl.addEventListener('focus', function(){
    searchEl.classList.add('focused');
    searchInputEl.setAttribute('placeholder','통합검색');
});

searchInputEl.addEventListener('blur', function(){
    searchEl.classList.remove('focused');
    searchInputEl.setAttribute('placeholder','');
});

// Badges
const badgeEl = document.querySelector('header .badges');

window.addEventListener('scroll', _.throttle(
    function(){
      console.log('scroll!!');
      if(window.scrollY > 500){
        //배지 숨기기
        badgeEl.style.display = 'none';
        //구글링: gsap cdn
        //gsap.to(요소, 지속시간(s), 옵션);
        //주의: 시작적으로만 사라진다. --> display 옵션 추가
        gsap.to(badgeEl, 0.6, {
          opacity: 0,
          display: 'none'
        });
  
        //to-top button  보이기
        gsap.to('#to-top', 0.2, {
          x: 0
        });
      }
      else{
        badgeEl.style.display = 'block';
        gsap.to(badgeEl, 0.6, {
          opacity: 1,
          display: 'block'
        });
  
        //to-top button  숨기기: 오른쪽으로 이동
        gsap.to('#to-top', 0.2, {
          x: 100
        });
        
  
      }
    }, 300));
  
  const fadeEls=document.querySelectorAll('.visual .fade-in');
  fadeEls.forEach(function(fadeEl, index){
    gsap.to(fadeEl, 1,{
      delay: (index+1)*0.7,  //0.7 1.4 2.1 2.7 sec
      opacity:1
    });  
  });
        
    